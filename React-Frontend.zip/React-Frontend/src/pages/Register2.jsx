import React from 'react'
import "./Register2.css";
import {Link} from 'react-router-dom'
import { Footer, Navbar } from "../components";




const Register2 = () => {
  return (

    <>
    <Navbar/>
    <div class="container login-container">
            <div class="row">
                <div class="col-md-6 login-form-1">
                    <h3>Register as a Seller</h3>
                    <form>
                        
                        <div class="form-group">
                        <Link to="/registerSeller">
                            <input type="submit" class="btnSubmit" value="Register" />
                        </Link>
                        </div>
                        
                        </form>
                    
                </div>
                <div class="col-md-6 login-form-2">
                    <div class="login-logo">
                        <img src="https://image.ibb.co/n7oTvU/logo_white.png" alt=""/>
                    </div>
                    <h3>Register as a Customer </h3>
                    <form>
                      
                        <div class="form-group">
                        <Link to="/registerCustomer">
                            <input type="submit" class="btnSubmit" value="Register" />
                        </Link>
                        </div>
                     
                    </form>
                </div>
            </div>
        </div>
    <Footer/>
    
    </>
    
  )
}

export default Register2