import React from 'react'
import { Link } from 'react-router-dom'
import Navbar from '../../COMPONENTS/Navbar/Navbar'
import './AuthPage.css'
const SignupSeller = () => {
    return (
        <div className='authpage'>
            <Navbar reloadnavbar={false}/>

            <div className='authcont'>
                <img src='https://images.unsplash.com/photo-1495480137269-ff29bd0a695c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1172&q=80'
                    alt='signup' />

                <form className='authform'>
                    <h1>Register as a Seller</h1>
                    <div className='form-group-row'>
                        <div className='formgroup'>
                            <label htmlFor='Ano'>Application No.</label>
                            <input type='text' id='Ano' />
                        </div>

                        <div className='formgroup'>
                            <label htmlFor='fname'>Full Name</label>
                            <input type='text' id='fname' />
                        </div>

                    </div>
                    <div className='form-group-row'>
                    <div className='formgroup'>
                        <label htmlFor='Certi'>Certificate No.</label>
                        <input type='text' id='Certi' />
                    </div>

                    <div className='formgroup'>
                        <label htmlFor='Gi'>GI Indication No.</label>
                        <input type='text' id='Gi' />
                    </div>
                    </div>


                    <div className='form-group-row'>

                        <div className='formgroup'>
                            <label htmlFor='certificate'>Certificate</label>
                            <input type='file' id='certificate' />
                        </div>

                        <div className='formgroup'>
                        <label htmlFor='city'>City</label>
                        <input type='text' id='city' />
                        </div>

                    </div>


                    <div className='form-group-row'>

                    <div className='formgroup'>
                        <label htmlFor='mob'>Mobile No.</label>
                        <input type='number' id='mob' />
                    </div>

                    <div className='formgroup'>
                    <label htmlFor='email'>Email-id</label>
                    <input type='email' id='email' />
                    </div>
                    </div>

                    <div className='form-group-row'>

                    <div className='formgroup'>
                        <label htmlFor='uname'>User Name</label>
                        <input type='text' id='uname' />
                    </div>

                    <div className='formgroup'>
                    <label htmlFor='pass'>Password</label>
                    <input type='password' id='pass' />
                    </div>
                    </div>

                    <Link to='/login'
                        className='stylenone'
                    >
                        <p>Already have an account?</p>
                    </Link>
                    <Link to='/signup'
                        className='stylenone'
                    >
                        <button className='btn'>Signup</button>
                    </Link>
                </form>
            </div>
        </div>
    )
}

export default SignupSeller