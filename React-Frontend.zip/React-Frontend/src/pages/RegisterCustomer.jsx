import React from 'react'
import "./RegisterCustomer.css";
import { Footer, Navbar } from "../components";
import { Link } from 'react-router-dom';



const RegisterCustomer = () => {
  return (
<>
<Navbar />
    <head>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"></link>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    </head>

    <div class="container login-container">

                <div class="col-md-6 login-form-2">
                    <h3>Customer Registeration</h3>
                    <form>
                        
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Full Name *" required  />
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="City *" required />
                        </div>

                        <div class="form-group">
                            <input type="number" class="form-control" placeholder="Mobile no. *" required />
                        </div>

                        <div class="form-group">
                            <input type="email" class="form-control" placeholder="Email no. *" required />
                        </div>

                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="User Name *" required />
                        </div>

                        <div class="form-group">
                            <input type="password" class="form-control" placeholder="Your Password *" />
                        </div>
                        <div class="form-group">
                            <input type="submit" class="btnSubmit" value="Register" />
                        </div>  
                    </form>
                </div>
            </div>
      


            </>

   
  )
}

export default RegisterCustomer